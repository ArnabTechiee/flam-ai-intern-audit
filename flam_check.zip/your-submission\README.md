# FLAM AI Intern — The Audit
Setup: `pip install tiktoken transformers sentencepiece protobuf regex numpy`
Corpus: download FLORES-200 into `data/` (see NOTEBOOK.md, Experiment 4), then:
    python your-submission/partA/prepare_corpus.py
    python your-submission/partA/audit.py        # A2: one flaw at a time
    python your-submission/partA/analyze.py      # A3: 5 tokenizers × 4 denominators
    python your-submission/partB/capacity.py     # B1–B3
    python your-submission/partA/extras.py       # corpus effect + NFC token effect
    python your-submission/partA/nfc_check.py    # which characters NFC changes
    python your-submission/partB/estimates.py    # FP8 + Part C GPU predictions
    python your-submission/partC/make_pairs.py   # then rate_timer.py (interactive)
Run from the repo root, with PYTHONIOENCODING=utf-8 on Windows.
Memos: partA/memo.md, partB/answers.md, partC/memo.md.